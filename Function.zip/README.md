# Image-Lambda Lab
### Aysia Brown

- AWSImageResizeS3Policy
- ImageResizeS3Role
- Followed These [AWS Docs](https://docs.aws.amazon.com/lambda/latest/dg/with-s3-example.html)
- Unsplash Test Photo [Credit](https://unsplash.com/photos/jwqgM5o6TVM)